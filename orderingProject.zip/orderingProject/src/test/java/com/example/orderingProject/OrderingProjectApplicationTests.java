package com.example.orderingProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
