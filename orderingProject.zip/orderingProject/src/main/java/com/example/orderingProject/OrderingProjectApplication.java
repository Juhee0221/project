package com.example.orderingProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderingProjectApplication.class, args);
	}

}
